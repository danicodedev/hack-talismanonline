# Talisman Mini Cheat

# How To Install
* Download ZIP File
* Put 'skills.txt' and 'cheatmenu.txt' And 'ui' Folder Into Talisman Main Folder
* Goto 'ui' Folder > Open 'ui.xml' With Text Editor (Recommend: Notepad++)
* Search For Following Pattern
 `<File Name="<FileName>.xml" />`
* For Example:
 `<File Name="lay_login.xml" />`
* After That Create New Line And Type This
 `<File Name="frm_cheatmenu.xml"/>`
* Close And Save
* Right-Click 'ui.xml' & Open Properties
* Check Read-only To Prevent Launcher From Updating It

# How To Use
* When You Join Game, Menu Appears
* Don't Close It! (You Wont Open It Unless You Restart Talisman)
* Left Side Contains Most Of PTO Skills
* When You Choose Skill, Click Try Learn Skill & Click Yes
* Also Skill Button Will Appear With Its Icon
* You Can Drag And Drop Anywhere That Icon To Use
* On Right Side You See Other Features Such As Combine
* Some Of Them May Not Work, They Need Additional Code Modification

# Additional Infos
* You Wont Get Banned By This, Unless You Use Paranormal Skills Near GM. Just Go And Farm In Caves Maybe
* If You Want To Get High HP/DMG, Use Skills From 1000 To 1008 (PTO) [FIXED IN PTO]
* Other Useful Skills From 20004 To 20006 (PTO) [FIXED IN PTO]

## Warning, You Might Break Your Damage By Using Some Skills
